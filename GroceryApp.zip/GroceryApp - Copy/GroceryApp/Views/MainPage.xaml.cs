﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace GroceryApp
{
    public partial class MainPage : ContentPage, Interfaces.IObserver
    {

        public MainPage()
        {
            InitializeComponent();
            DataManager.DataMgr.GetInstance().RegisterObserver(this);

        }

        async void ToolbarItem_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Page1());
        }

        public void Update(List<Models.GroceryModel> value)
        {
            ItemList.ItemsSource = value;
            HideLBL.IsVisible = DataManager.DataMgr.GetInstance().ListEmpty();
        }

        async public void ItemList_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            Models.GroceryModel groceryItem = (Models.GroceryModel)e.SelectedItem;
            await Navigation.PushAsync(new Page1(groceryItem));
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace GroceryApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Page1 : ContentPage
    {

        Boolean isEdit = false;
        readonly Models.GroceryModel itemFocused;

        readonly List<string> categoryLIST = new List<string>(14) {
            "Baking", "Beverages", "Bread", "Cereal",
            "Candy and Snacks", "Canned","Condiments", "Dairy",
            "Boxed Food and Pasta", "Paper and Cleaning",
            "Meat", "Personal Care", "Alcohol", "Tobacco",
            "Lottery"};
        
        public Page1()
        {
            InitializeComponent();
            picker.ItemsSource = categoryLIST;
            DeleteBTN.IsVisible = false;
        }

        public Page1(Models.GroceryModel toEdit)
        {
            InitializeComponent();
            NameField.Text = toEdit.Name;
            QuantityField.Text = toEdit.Quantity.ToString();
            picker.ItemsSource = categoryLIST;
            int itemIndex = SearchList(categoryLIST, toEdit.Category);
            picker.SelectedIndex = itemIndex;
            DeleteBTN.IsVisible = true;
            isEdit = true;
            itemFocused = toEdit;
        }

        void SaveBTN_Clicked(object sender, EventArgs e)
        {
            if (NameField.Text != null)
            {
                decimal.TryParse(QuantityField.Text, out decimal quantity);
                if (!isEdit)
                {
                    DataManager.DataMgr.GetInstance().AddItem(new Models.GroceryModel(NameField.Text, quantity == 0 ? null : quantity, picker.SelectedIndex == -1 ? null : categoryLIST[picker.SelectedIndex]));
                }
                else
                {
                    // Update an existing item in DataMgr
                    DataManager.DataMgr.GetInstance().UpdateItem(itemFocused.ItemID, NameField.Text, quantity == 0 ? null : quantity, picker.SelectedIndex == -1 ? null : categoryLIST[picker.SelectedIndex]);
                }
                Navigation.PopAsync();
            }
            else
            {
                ShowError();
            }
            
            
        }

        void CancelBTN_Clicked(object sender, EventArgs e)
        {
            Navigation.PopAsync();
        }

        int SearchList(List<string> lst, string toFind)
        {
            int index = -1;
            for (int i = 0; i < lst.Count; i++)
            {
                if (lst[i].Equals(toFind))
                {
                    index = i;
                    break;
                }
            }
            return index;
        }

        async void ShowError()
        {
            await DisplayAlert("Error", "Name field is required", "OK");
        }

        void DeleteBTN_Clicked(object sender, EventArgs e)
        {
            //Delete the item
            DataManager.DataMgr.GetInstance().DeleteItem(itemFocused);
            Navigation.PopAsync();
        }
    }
}
﻿using System;

namespace GroceryApp.Models
{
    public class GroceryModel
    {
        public string Name { get; set; }

        public decimal? Quantity { get; set; }

        public string Category { get; set; }

        public Guid ItemID { get; }
        public string gName { get; set; }

        public GroceryModel(string _name, decimal? _quantity, string _category)
        {
            Name = _name;
            Quantity = _quantity;
            Category = _category;
            ItemID = Guid.NewGuid();
            gName = Category + " - " + Name;
        }

        public override string ToString()
        {
            return "Grocery item {" + Name + " | " + Quantity + " | " + Category + "}"+gName;
        }
    }
}
